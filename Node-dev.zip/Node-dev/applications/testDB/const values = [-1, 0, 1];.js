const values = [-1, 0, 3];

values.forEach(num => {
  console.log(`${num} is ${Boolean(num)}`);
});

// Or using a simple if statement
const check = (val) => val ? "truthy" : "falsy";

console.log(check(-1));
console.log(check(0));
console.log(check(1));


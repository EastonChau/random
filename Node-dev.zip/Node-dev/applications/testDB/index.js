// Created by Easton
var app = require('express')();
var mongoose = require('mongoose')

// task a

mongoose.connect('mongodb://c3322-mongo:27017/Cities')

const db = mongoose.connection;

db.once('open', () => {
  console.log('MongoDB Connected! Congrats!');
});
db.on('error', (error) => {
  console.error('DB error:', error);
  process.exit(1);
});
db.on('disconnected', () => {
  console.error('Disconnected!');
  process.exit(1);
});

const citySchema = new mongoose.Schema({
  _id: Number,
  "UTF8 Name": String,
  "ASCII Name": String,
  "Latitude": Number,
  "Longitude": Number,
  "Alpha-2 Code": String,
  "ISO Name EN": String,
  "Population": Number,
  "Timezone": String,
  "Modification Date": String
});

const City = mongoose.model('City', citySchema, 'cities5000');

// task b
app.get('/cities/v1/all', async (req, res) => {
  try {
    //const { gte, lte } = req.query;
    const gte = req.query.gte;
    const lte = req.query.lte;
    
    let query = {};
    if (gte !== undefined && lte !== undefined){
      query.Population = {$gte: parseInt(gte), $lte: parseInt(lte)};  
      //query.Population.$gte = parseInt(gte);
      //query.Population.$lte = parseInt(lte);
    } else if (gte !== undefined){
      query.Population = {};
      query.Population.$gte = parseInt(gte);
    } else if (lte !== undefined){
      query.Population = {$lte: parseInt(lte)};
    }
    let cities = await City.find(query).lean();
    if (!cities || cities.length ===0){
      return res.status(404).json({
        error: `No record for this population range: lte=${lte} gte=${gte}` 
      });
    }
    const cities_transformed = cities.map(city => ({
      "UTF8 Name": city["UTF8 Name"],
      "ASCII Name": city["ASCII Name"],
      "Coordinates": {
          "Lat": city["Latitude"],
          "Lng": city["Longitude"]
      },
      "Alpha-2 Code": city["Alpha-2 Code"],
      "ISO Name EN": city["ISO Name EN"],
      "Population": city["Population"],
      "Timezone": city["Timezone"],
      "Modification Date": city["Modification Date"]
    }));
    
    if (gte === undefined && lte ===undefined){
      cities_transformed.sort((a,b) => {
        const compare = a["Alpha-2 Code"].localeCompare(b["Alpha-2 Code"]);
        if (compare){
          return compare;
        } else {
          return a.Population - b.Population;
        }
      });
    } else {
      cities_transformed.sort((a, b) => b.Population - a.Population);
    }
    res.status(200).json(cities_transformed);
    
  } catch (error){
    res.status(500).json({error: error.message});
  }

});
//task c: /cities/v1/alpha/
app.get('/cities/v1/alpha', async (req, res) => {
  try {
    const result_unique_alpha_name = await City.aggregate([
      {
        $group: {
          _id:{
            code: "$Alpha-2 Code",
            name: "$ISO Name EN"
          }
        }
      },

      {
        $project: {
          Code: "$_id.code",
          Name: "$_id.name",
          _id: 0
        }
      },
      {
        $sort: {
          Code: 1
        }
      }
    ]);

    res.status(200).json(result_unique_alpha_name);
  } catch (error) {
    res.status(500).json({error: error.message, message: "task c1"});
  }

});
//task c: /cities/v1/alpha/{code}
app.get('/cities/v1/alpha/:code', async (q,s) =>{
  try{
    code = q.params.code.toUpperCase();
    const cities = await City.find({"Alpha-2 Code": code}).lean();
    
    if (cities.length === 0) {
      return s.status(404).json({
        error: `No record for this request - ${code}`,
        message: "No record"
      });
    }

    const cities_trans = cities.map(city => ({
      "ASCII Name": city["ASCII Name"],
      "Population": city["Population"],
      "Timezone": city["Timezone"],
      "Coordinates": {
        "Lat": city["Latitude"],
        "Lng": city["Longitude"]
      }
    }));
    cities_trans.sort((a,b)=> b.Population - a.Population);
    s.status(200).json(cities_trans)
  
  }catch(error) {
    s.status(500).json({error: error.message, message: "task c2 error"})
  }


});
//task d: /cities/v1/timezone
app.get('/cities/v1/timezone',async (q,s) =>{
  try{const cities = await City.find().lean();
    const regions = {};

    cities.forEach(city =>{
      const timezone = city.Timezone;
      if (!timezone) return;

      const timezone_parts = timezone.split('/');
      const region = timezone_parts[0];
      const area = timezone_parts.slice(1).join('/');
      if (!regions[region]){
        regions[region] = new Set();
      }
      regions[region].add(area);
    });

    const result = {};
    for (const each of Object.entries(regions).sort()){
      result[each[0]] = Array.from(each[1]).sort();
    }
    s.status(200).json(result);

  }catch (error){
    s.status(500).json({error: error.message, message: 'd2'});
  }
});
//d2
app.get('/cities/v1/timezone/:region{/:area}', async (q, s) => {
    try {
      const {region: regi,area: are} = q.params;
      
      let query = {};

      if (are) {
        query.Timezone = `${regi}/${are}`;
      } else {
        query.Timezone = {$regex: `^${regi}/`, $options: ''};
      }

      const cities = await City.find(query).lean();
      if (cities.length === 0) {
        return s.status(404).json({error: `No record for this request - ${regi}${are ? '/'+are : ''}`});
      }

      const cities_trans = cities.map(c => ({
        "ASCII Name": c["ASCII Name"],
        "Alpha-2 Code": c["Alpha-2 Code"],
        "ISO Name EN": c["ISO Name EN"],
        "Population": c["Population"],
        "Timezone": c["Timezone"],
        "Coordinates": {
          "Lat": c["Latitude"],"Lng":c["Longitude"]
        }
      }));

      cities_trans.sort((a, b) => b.Population - a.Population);

      s.status(200).json(cities_trans);

    } catch (error) {s.status(500).json({error: error.message, message: 'd2'});}
});

//task e
app.get('/cities/v1/:city', async (q, s) => {
    try {
      const cityName = decodeURIComponent(q.params.city);
      const {partial,alpha,region} = q.query;
      let quer = {};
  
      if (partial === 'true') {
        quer["ASCII Name"] = {$regex: cityName, $options: ''};
      } else {
        quer["ASCII Name"] = cityName;
      }

      if (alpha) {
        quer["Alpha-2 Code"] = alpha.toUpperCase();
      } else if (region) {
        quer.Timezone = { $regex: `^${region}/`, $options: '' };
      }
      
      const cities = await City.find(quer).lean();
      
      if (cities.length === 0) {
        return s.status(404).json({error: `No record for this city name ${cityName}`});
      }
      
      const ct_trans = cities.map(c => ({
          "ASCII Name": c["ASCII Name"],
          "Alpha-2 Code": c["Alpha-2 Code"],
          "ISO Name EN": c["ISO Name EN"],
          "Population":c["Population"],
          "Timezone": c["Timezone"],
          "Coordinates": {"Lat": c["Latitude"],  "Lng": c["Longitude"]
          }
      }));
      
      ct_trans.sort(function(cita, citb){
        const pa = cita.Population;
        const pb = citb.Population;
        return (pb - pa);
      });
      
      s.status(200).json(ct_trans);
        
    } catch (error) {s.status(500).json({error: error.message, message: 'task e error'});}
});

// task f
app.all('/*path', (q, s) => {
    res.status(400).json({error: `Cannot ${q.method} ${q.originalUrl}`, message: "task f"});
});



// error handler
app.use(function(err, req, res, next) {
  res.status(err.status || 500);
  res.json({'error': err.message});
});


app.listen(8080, () => {
  console.log('City app listening on port 8080!')
});
